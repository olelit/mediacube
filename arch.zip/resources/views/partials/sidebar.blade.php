<div class="nav flex-column sidebar">
    <div class="sidebar-head">
        <a href="">
            <div class="avatar-psevdo">
                <i class="fas fa-user-tie"></i>
                <div class="sidebar-hidden">
                    MediaCube
                </div>
            </div>
        </a>
    </div>
    <ul>
        <li class="side-link"><a href="/"><i class="fas fa-atlas"></i><div class="sidebar-hidden">Главная</div></a></li>
        <li class="side-link"><a href="{{route('employees.index')}}"><i class="fas fa-address-card"></i><div class="sidebar-hidden">Сотрудники</div></a></li>
        <li class="side-link"><a href="{{route('departments.index')}}"><i class="fas fa-briefcase"></i><div class="sidebar-hidden">Отделы</div></a></li>
    </ul>
</div>
