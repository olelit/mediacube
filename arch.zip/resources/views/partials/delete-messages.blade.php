<div id="success" class="alert alert-success d-none" role="alert">
    Отдел успешно удален
</div>
<div id="fail" class="alert alert-danger d-none" role="alert">
    Нельзя удалить отдел в котором есть сотрудники
</div>
