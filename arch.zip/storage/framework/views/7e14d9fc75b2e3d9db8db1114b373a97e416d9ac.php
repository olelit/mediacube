<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('employees.update',$employee)); ?>" method="post">
    <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Имя:</label>
            <input type="text" name="firstname" value="<?php echo e($employee->firstname); ?>" class="form-control">
        </div>
        <div class="form-group">
            <label for="name">Фамилия:</label>
            <input type="text" name="surname" value="<?php echo e($employee->surname); ?>" class="form-control">
        </div>
        <div class="form-group">
            <label for="name">Отчество:</label>
            <input type="text" name="fathername" value="<?php echo e($employee->fathername); ?>" class="form-control">
        </div>
        <?php echo $__env->make('providers.gender-component', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="form-group">
            <label for="name">Заработная плата:</label>
            <input type="text" name="payment" value="<?php echo e($employee->payment); ?>" class="form-control">
        </div>
        <?php echo $__env->make('providers.department-component', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <button type="submit" class="btn btn-primary">Сохранить</button>
        <a href="<?php echo e(route('employees.index')); ?>" class="btn btn-danger">Отмена</a>
</form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('templates.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>