<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <a href="<?php echo e(route('employees.create')); ?>" class="btn btn-success">Добавить сотрудника</a>
        </div>
    </div>

    <?php echo $__env->make('partials.delete-messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <table class="table">
        <thead>
            <th>№</th>
            <th>Имя</th>
            <th>Фамилия</th>
            <th>Отчество</th>
            <th>Пол</th>
            <th>Заработная плата</th>
            <th>Отделы</th>
            <th>Действия</th>
        </thead>
        <tbody>
            <?php if(count($employees) > 0): ?>
            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(++$key); ?></td>
                    <td><?php echo e($value->firstname); ?></td>
                    <td><?php echo e($value->surname); ?></td>
                    <td><?php echo e($value->fathername ?? "неизвестно"); ?></td>
                    <td><?php echo e($value->gender->name ?? "неизвестно"); ?></td>
                    <td><?php echo e($value->payment); ?></td>
                    <td><?php echo e(implode(", ",$value->departments->pluck('name')->toArray())); ?></td>
                    <td>
                        <a title="Изменить" class="btn btn-primary" href="<?php echo e(route('employees.edit',['department' => $value])); ?>"><i class="fas fa-pen-square"></i></a>
                        <a title="Удалить" class="btn btn-danger delete-data" href="<?php echo e(route('employees.destroy',['id' => $value->id])); ?>"><i class="fas fa-trash-alt"></i></a>
                    </td>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>

                <tr>
                    <td>
                        Нет информации о сотрудниках
                    </td>
                </tr>

        <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>