<?php $__env->startSection('content'); ?>
    <h3 class="mt-3">Добавить сотрудника</h3>
    <hr>
    <form class="" action="<?php echo e(route('employees.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="firstname">Имя:</label>
            <input type="text" name="firstname" class="form-control">
            <?php if($errors->has('firstname')): ?>
                <span class="text-danger"><?php echo e($errors->first('firstname')); ?></span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <label for="surname">Фамилия:</label>
            <input type="text" name="surname" class="form-control">
            <?php if($errors->has('surname')): ?>
                <span class="text-danger"><?php echo e($errors->first('surname')); ?></span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <label for="fathername">Отчество:</label>
            <input type="text" name="fathername" class="form-control">
        </div>
        <?php echo $__env->make('providers.gender-component', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="form-group">
            <label for="payment">Заработная плата:</label>
            <input type="number" required value="0" name="payment" class="form-control">
        </div>
        <?php echo $__env->make('providers.department-component', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <button type="submit" class="btn btn-primary">Сохранить</button>
        <a href="<?php echo e(route('employees.index')); ?>" class="btn btn-danger">Отмена</a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>