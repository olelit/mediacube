<?php $__env->startSection('content'); ?>
    <h3 class="mt-3">Добавить отдел</h3>
    <hr>
    <form action="<?php echo e(route('departments.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Название отдела:</label>
            <input type="text" name="name" class="form-control">
        </div>
        <button type="submit" class="btn btn-primary">Сохранить</button>
        <a href="<?php echo e(route('departments.index')); ?>" class="btn btn-danger">Отмена</a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>