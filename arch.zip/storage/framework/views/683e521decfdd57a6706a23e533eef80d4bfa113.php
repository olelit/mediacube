<div class="form-group">
    <label for="departments">Отделы:</label>
    <select class="form-control" name="departments[]" multiple id="">
        <?php $__currentLoopData = $departmentProvider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php if(isset($employee) && $employee->departments->contains('id',$department->id)): ?> selected <?php endif; ?> value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php if($errors->has('departments')): ?>
        <span class="text-danger"><?php echo e($errors->first('departments')); ?></span>
    <?php endif; ?>
</div>
