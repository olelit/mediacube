<?php echo e(dd($gendersProvider)); ?>

<div class="form-group">
    <label for="name">Пол:</label>
    <input type="text" name="gender_id" class="form-control">
</div>
