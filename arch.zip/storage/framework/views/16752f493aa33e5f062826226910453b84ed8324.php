<div class="form-group">
    <label for="gender_id">Отделы:</label>
    <?php $__currentLoopData = $gendersProvider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <br>
        <input type="radio" <?php if(isset($employee) && $employee->gender_id == $gender->id): ?> checked <?php endif; ?> name="gender_id" value="<?php echo e($gender->id); ?>" class=""><?php echo e($gender->name); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
